package com.grabadormeme.app

import android.content.Context
import android.graphics.PixelFormat
import android.view.*
import android.widget.FrameLayout

/**
 * Dos ventanas overlay (TYPE_ACCESSIBILITY_OVERLAY, no requieren "mostrar sobre otras apps"):
 *  - touchView: 1x1 px con FLAG_WATCH_OUTSIDE_TOUCH; recibe ACTION_OUTSIDE por cada toque en cualquier parte.
 *    En Android 10+ ese evento NO trae coordenadas de otras apps, por eso el meme sale centrado (+ offset aleatorio).
 *  - root: pantalla completa, NOT_TOUCHABLE, donde se dibujan las secuencias (MediaProjection las captura).
 * Alternativa descartada: modo exploración táctil del AccessibilityService; da coordenadas pero altera el uso normal del celular.
 */
class TouchOverlayManager(private val ctx: Context) {
    private val wm = ctx.getSystemService(WindowManager::class.java)
    private val touchView = View(ctx)
    private val root = FrameLayout(ctx)

    fun attach() {
        touchView.setOnTouchListener { _, e -> if (e.action == MotionEvent.ACTION_OUTSIDE) onTap(); false }
        wm.addView(touchView, WindowManager.LayoutParams(1, 1, WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH, PixelFormat.TRANSLUCENT)
            .apply { gravity = Gravity.TOP or Gravity.START })
        wm.addView(root, WindowManager.LayoutParams(-1, -1, WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT))
    }

    fun detach() { runCatching { wm.removeView(touchView) }; runCatching { wm.removeView(root) } }

    private fun onTap() {
        if (!RecordingState.recording.value || root.childCount >= 5) return   // máx. 5 secuencias simultáneas
        val v = MemeEffectView(ctx)
        root.addView(v, FrameLayout.LayoutParams(-1, -1))
        v.play { root.removeView(v) }
    }
}
