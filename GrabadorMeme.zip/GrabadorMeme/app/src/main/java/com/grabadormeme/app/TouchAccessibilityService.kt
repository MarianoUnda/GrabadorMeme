package com.grabadormeme.app

import android.accessibilityservice.AccessibilityService
import android.view.accessibility.AccessibilityEvent

class TouchAccessibilityService : AccessibilityService() {
    private var mgr: TouchOverlayManager? = null
    override fun onServiceConnected() { mgr = TouchOverlayManager(this).also { it.attach() } }
    override fun onAccessibilityEvent(e: AccessibilityEvent?) {}
    override fun onInterrupt() {}
    override fun onDestroy() { mgr?.detach(); super.onDestroy() }
}
