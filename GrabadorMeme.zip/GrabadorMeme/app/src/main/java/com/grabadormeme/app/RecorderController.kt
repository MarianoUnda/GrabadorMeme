package com.grabadormeme.app

import android.content.*
import android.hardware.display.*
import android.media.MediaRecorder
import android.media.projection.MediaProjection
import android.net.Uri
import android.os.*
import android.provider.MediaStore
import android.util.DisplayMetrics
import android.view.WindowManager

/** Graba la pantalla en MP4 H.264 a 30 fps y la guarda en Movies/GrabadorMeme con MediaStore. */
class RecorderController(
    private val ctx: Context, private val proj: MediaProjection,
    private val audio: Boolean, private val onProjStop: () -> Unit
) {
    private val rec = if (Build.VERSION.SDK_INT >= 31) MediaRecorder(ctx) else @Suppress("DEPRECATION") MediaRecorder()
    private var vd: VirtualDisplay? = null
    private var pfd: ParcelFileDescriptor? = null
    var uri: Uri? = null; private set

    @Suppress("DEPRECATION")
    fun start() {
        if (StatFs(Environment.getExternalStorageDirectory().path).availableBytes < (200L shl 20))
            throw IllegalStateException("No hay espacio suficiente (se necesitan 200 MB libres).")
        val dm = DisplayMetrics()
        ctx.getSystemService(WindowManager::class.java).defaultDisplay.getRealMetrics(dm)
        val w = dm.widthPixels and 1.inv(); val h = dm.heightPixels and 1.inv()
        val cv = ContentValues().apply {
            put(MediaStore.Video.Media.DISPLAY_NAME, "meme_${System.currentTimeMillis()}.mp4")
            put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
            put(MediaStore.Video.Media.RELATIVE_PATH, "Movies/GrabadorMeme")
            put(MediaStore.Video.Media.IS_PENDING, 1)
        }
        uri = ctx.contentResolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, cv)
        pfd = ctx.contentResolver.openFileDescriptor(uri!!, "w")
        rec.apply {
            if (audio) setAudioSource(MediaRecorder.AudioSource.MIC)
            setVideoSource(MediaRecorder.VideoSource.SURFACE)
            setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
            setOutputFile(pfd!!.fileDescriptor)
            setVideoEncoder(MediaRecorder.VideoEncoder.H264)
            if (audio) setAudioEncoder(MediaRecorder.AudioEncoder.AAC)
            setVideoSize(w, h); setVideoFrameRate(30); setVideoEncodingBitRate(8_000_000)
            prepare()
        }
        // Android 14 exige registrar el callback antes de crear el VirtualDisplay
        proj.registerCallback(object : MediaProjection.Callback() { override fun onStop() = onProjStop() }, Handler(Looper.getMainLooper()))
        vd = proj.createVirtualDisplay("GrabadorMeme", w, h, dm.densityDpi,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, rec.surface, null, null)
        rec.start()
    }

    fun stop() {
        runCatching { rec.stop() }; rec.release(); vd?.release(); proj.stop(); pfd?.close()
        uri?.let { ctx.contentResolver.update(it, ContentValues().apply { put(MediaStore.Video.Media.IS_PENDING, 0) }, null, null) }
    }
}
