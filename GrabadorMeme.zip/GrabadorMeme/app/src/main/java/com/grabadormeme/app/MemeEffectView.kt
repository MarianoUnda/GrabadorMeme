package com.grabadormeme.app

import android.animation.*
import android.content.Context
import android.graphics.*
import android.graphics.drawable.GradientDrawable
import android.util.TypedValue
import android.view.*
import android.view.animation.LinearInterpolator
import android.widget.*
import androidx.core.view.doOnLayout

/** Una secuencia de 6 s: meme (0-3 s, fundido en los últimos 1,5 s) y luego cartel (3-6 s). */
class MemeEffectView(ctx: Context) : FrameLayout(ctx) {
    private val d = resources.displayMetrics.density
    private val img = ImageView(ctx).apply {
        setImageResource(R.drawable.meme); adjustViewBounds = true
        outlineProvider = object : ViewOutlineProvider() {
            override fun getOutline(v: View, o: Outline) = o.setRoundRect(0, 0, v.width, v.height, 24 * d)
        }
        clipToOutline = true
    }
    private val sign = TextView(ctx).apply {
        text = "colorado te doy media hora para soltarme"
        setTextColor(Color.WHITE); setTextSize(TypedValue.COMPLEX_UNIT_SP, 26f)
        typeface = Typeface.DEFAULT_BOLD; gravity = Gravity.CENTER
        setPadding((24 * d).toInt(), (20 * d).toInt(), (24 * d).toInt(), (20 * d).toInt())
        background = GradientDrawable().apply { setColor(0xCC000000.toInt()); cornerRadius = 24 * d }
        alpha = 0f
    }

    init {
        addView(img, LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT, Gravity.CENTER))
        addView(sign, LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT, Gravity.CENTER))
    }

    fun play(onEnd: () -> Unit) = doOnLayout {
        img.layoutParams = img.layoutParams.apply { width = (width * 0.7f).toInt() }
        sign.maxWidth = (width * 0.85f).toInt()
        translationX = (Math.random().toFloat() - .5f) * .2f * width   // leve desplazamiento aleatorio
        translationY = (Math.random().toFloat() - .5f) * .2f * height
        fun fade(v: View, a: Float, b: Float, delay: Long, dur: Long) =
            ObjectAnimator.ofFloat(v, View.ALPHA, a, b).apply { startDelay = delay; duration = dur }
        val anims = listOf<Animator>(
            ObjectAnimator.ofFloat(img, View.SCALE_X, .8f, 1f).apply { duration = 200 },
            ObjectAnimator.ofFloat(img, View.SCALE_Y, .8f, 1f).apply { duration = 200 },
            fade(img, 1f, 0f, 1500, 1500).apply { interpolator = LinearInterpolator() },
            fade(sign, 0f, 1f, 3000, 300),
            fade(sign, 1f, 0f, 5700, 300))
        AnimatorSet().apply {
            playTogether(anims)
            addListener(object : AnimatorListenerAdapter() { override fun onAnimationEnd(a: Animator) = onEnd() })
        }.start()
    }
}
