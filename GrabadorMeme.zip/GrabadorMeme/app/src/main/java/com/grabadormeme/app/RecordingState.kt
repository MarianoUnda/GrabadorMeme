package com.grabadormeme.app

import android.net.Uri
import kotlinx.coroutines.flow.MutableStateFlow

/** Estado compartido entre el servicio de grabación, el de accesibilidad y la UI. */
object RecordingState {
    val recording = MutableStateFlow(false)
    val lastUri = MutableStateFlow<Uri?>(null)
    val error = MutableStateFlow<String?>(null)
}
