package com.grabadormeme.app

import android.app.*
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.drawable.Icon
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.IBinder
import androidx.core.content.IntentCompat

class ScreenRecordService : Service() {
    private var rec: RecorderController? = null
    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(i: Intent?, flags: Int, id: Int): Int {
        if (i?.action == ACTION_STOP) { stopRec(); return START_NOT_STICKY }
        if (rec != null) return START_NOT_STICKY
        val audio = i?.getBooleanExtra(EXTRA_AUDIO, false) == true
        val data = i?.let { IntentCompat.getParcelableExtra(it, EXTRA_DATA, Intent::class.java) }
        if (data == null) { fail("No se recibió el permiso de captura."); return START_NOT_STICKY }
        try {
            var type = ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION
            if (audio && Build.VERSION.SDK_INT >= 30) type = type or ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE
            startForeground(1, notification(), type)   // antes de getMediaProjection (obligatorio en Android 14)
            val proj = getSystemService(MediaProjectionManager::class.java).getMediaProjection(i!!.getIntExtra(EXTRA_CODE, 0), data)
            rec = RecorderController(this, proj, audio) {
                if (rec != null) { RecordingState.error.value = "La grabación fue detenida por el sistema."; stopRec() }
            }.also { it.start() }
            RecordingState.error.value = null; RecordingState.lastUri.value = null
            RecordingState.recording.value = true
        } catch (e: Exception) {
            rec?.let { runCatching { it.stop() } }; rec = null
            fail(e.message ?: "No se pudo iniciar la grabación.")
        }
        return START_NOT_STICKY
    }

    private fun stopRec() {
        val r = rec ?: return
        rec = null
        RecordingState.recording.value = false
        runCatching { r.stop() }
        RecordingState.lastUri.value = r.uri
        stopForeground(STOP_FOREGROUND_REMOVE); stopSelf()
    }

    private fun fail(msg: String) {
        RecordingState.error.value = msg; RecordingState.recording.value = false
        stopForeground(STOP_FOREGROUND_REMOVE); stopSelf()
    }

    private fun notification(): Notification {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("rec", "Grabación", NotificationManager.IMPORTANCE_LOW))
        val pi = PendingIntent.getService(this, 0, Intent(this, ScreenRecordService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        return Notification.Builder(this, "rec").setContentTitle("Grabando pantalla")
            .setSmallIcon(android.R.drawable.ic_menu_camera).setOngoing(true)
            .addAction(Notification.Action.Builder(Icon.createWithResource(this, android.R.drawable.ic_media_pause), "Detener grabación", pi).build())
            .build()
    }

    override fun onDestroy() { rec?.let { runCatching { it.stop() } }; rec = null; RecordingState.recording.value = false; super.onDestroy() }

    companion object {
        const val ACTION_STOP = "com.grabadormeme.app.STOP"
        const val EXTRA_CODE = "code"; const val EXTRA_DATA = "data"; const val EXTRA_AUDIO = "audio"
    }
}
