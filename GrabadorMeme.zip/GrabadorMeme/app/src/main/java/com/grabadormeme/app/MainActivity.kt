package com.grabadormeme.app

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.FrameLayout
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat

class MainActivity : ComponentActivity() {
    private var wantAudio = false
    private var showA11y by mutableStateOf(false)

    private val projLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        val d = r.data
        if (r.resultCode == RESULT_OK && d != null)
            ContextCompat.startForegroundService(this, Intent(this, ScreenRecordService::class.java)
                .putExtra(ScreenRecordService.EXTRA_CODE, r.resultCode).putExtra(ScreenRecordService.EXTRA_DATA, d)
                .putExtra(ScreenRecordService.EXTRA_AUDIO, wantAudio))
        else RecordingState.error.value = "Permiso de captura de pantalla denegado."
    }
    private val permLauncher = registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { m ->
        if (m[Manifest.permission.RECORD_AUDIO] == false) {
            wantAudio = false; RecordingState.error.value = "Sin permiso de micrófono: se grabará sin audio."
        }
        afterPerms()
    }

    private fun begin(audio: Boolean) {
        wantAudio = audio; RecordingState.error.value = null
        val need = mutableListOf<String>()
        if (Build.VERSION.SDK_INT >= 33) need += Manifest.permission.POST_NOTIFICATIONS
        if (audio) need += Manifest.permission.RECORD_AUDIO
        val missing = need.filter { checkSelfPermission(it) != PackageManager.PERMISSION_GRANTED }
        if (missing.isEmpty()) afterPerms() else permLauncher.launch(missing.toTypedArray())
    }

    private fun a11yOn(): Boolean {
        val s = Settings.Secure.getString(contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: ""
        return s.contains(packageName) && s.contains("TouchAccessibilityService")
    }

    private fun afterPerms() {
        if (!a11yOn()) { showA11y = true; return }
        projLauncher.launch(getSystemService(MediaProjectionManager::class.java).createScreenCaptureIntent())
    }

    private fun stop() { startService(Intent(this, ScreenRecordService::class.java).setAction(ScreenRecordService.ACTION_STOP)) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MaterialTheme { Surface(Modifier.fillMaxSize()) { Screen() } } }
    }

    @Composable
    fun Screen() {
        val rec by RecordingState.recording.collectAsState()
        val uri by RecordingState.lastUri.collectAsState()
        val err by RecordingState.error.collectAsState()
        var audio by remember { mutableStateOf(false) }
        var info by remember { mutableStateOf(false) }
        var done by remember { mutableStateOf(false) }
        LaunchedEffect(uri) { if (uri != null) done = true }

        Column(Modifier.fillMaxSize().statusBarsPadding().padding(20.dp).verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Text("Grabador Meme", style = MaterialTheme.typography.headlineMedium)
            Row { Switch(audio, { audio = it }); Spacer(Modifier.width(12.dp)); Text("Grabar audio del micrófono") }
            Button({ info = true }, Modifier.fillMaxWidth().height(64.dp), enabled = !rec) { Text("Iniciar grabación") }
            OutlinedButton({ stop() }, Modifier.fillMaxWidth().height(48.dp), enabled = rec) { Text("Detener") }
            if (rec) Text("● Grabando… tocá la pantalla para disparar el meme.")
            err?.let { Text(it, color = MaterialTheme.colorScheme.error) }
            Text("Modo prueba: tocá el recuadro para ver la secuencia (sin grabar)", style = MaterialTheme.typography.labelLarge)
            AndroidView(factory = { c ->
                FrameLayout(c).apply {
                    setBackgroundColor(0xFF222222.toInt())
                    setOnClickListener {
                        if (childCount < 5) { val v = MemeEffectView(c); addView(v, FrameLayout.LayoutParams(-1, -1)); v.play { removeView(v) } }
                    }
                }
            }, Modifier.fillMaxWidth().height(380.dp).clip(RoundedCornerShape(16.dp)))
        }
        if (info) AlertDialog(onDismissRequest = { info = false }, title = { Text("Permisos necesarios") },
            text = { Text("1. Captura de pantalla: Android te pedirá permiso para grabar lo que se ve.\n2. Notificaciones: para el botón «Detener grabación».\n3. Micrófono: solo si activaste el audio.\n4. Servicio de accesibilidad «Grabador Meme»: detecta tus toques y dibuja el meme sobre la pantalla. No lee tu contenido.") },
            confirmButton = { TextButton({ info = false; begin(audio) }) { Text("Continuar") } },
            dismissButton = { TextButton({ info = false }) { Text("Cancelar") } })
        if (showA11y) AlertDialog(onDismissRequest = { showA11y = false }, title = { Text("Activar accesibilidad") },
            text = { Text("En Ajustes > Accesibilidad > Apps instaladas, activá «Grabador Meme». Después volvé y tocá «Iniciar grabación» otra vez.") },
            confirmButton = { TextButton({ showA11y = false; startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }) { Text("Abrir ajustes") } },
            dismissButton = { TextButton({ showA11y = false }) { Text("Cancelar") } })
        if (done) AlertDialog(onDismissRequest = { done = false }, title = { Text("Grabación guardada") },
            text = { Text("El video quedó en Movies/GrabadorMeme.") },
            confirmButton = { TextButton({ done = false; view(uri) }) { Text("Ver video") } },
            dismissButton = { TextButton({ done = false }) { Text("Cerrar") } })
    }

    private fun view(u: Uri?) {
        u ?: return
        startActivity(Intent(Intent.ACTION_VIEW).setDataAndType(u, "video/mp4").addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION))
    }
}
