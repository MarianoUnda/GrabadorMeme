# Grabador Meme

## Compilar
1. Abrí la carpeta en Android Studio (Koala o superior, JDK 17). Dejá que sincronice Gradle.
2. Conectá un celular Android 10+ con depuración USB y ejecutá ▶ Run.

## Permisos y uso
- Al tocar **Iniciar grabación** se piden: notificaciones, micrófono (solo con audio) y captura de pantalla.
- **Accesibilidad (obligatorio):** Ajustes > Accesibilidad > Apps instaladas > Grabador Meme > Activar.
  Con Android 13+ y APK instalado fuera de Play Store: Ajustes > Apps > Grabador Meme > ⋮ > "Permitir ajustes restringidos".
- Mientras graba, cada toque dispara 6 s: meme 3 s (fundido en los últimos 1,5 s) y cartel 3 s. Máx. 5 a la vez.
- El video se guarda en Movies/GrabadorMeme.

## Probar
"Modo prueba" en la pantalla principal muestra la secuencia sin grabar.

## Limitaciones
Android 10+ no entrega coordenadas de toques en otras apps (ACTION_OUTSIDE), por eso el meme sale centrado con un leve desplazamiento aleatorio.
En algunos fabricantes ACTION_OUTSIDE puede no dispararse en toda la pantalla.
